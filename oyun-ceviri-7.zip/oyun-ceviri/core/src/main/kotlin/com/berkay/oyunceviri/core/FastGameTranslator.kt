package com.berkay.oyunceviri.core

import java.util.Collections
import java.util.LinkedHashMap
import java.util.Locale

class FastGameTranslator {

    private val translationCache: MutableMap<String, String> = Collections.synchronizedMap(
        object : LinkedHashMap<String, String>(1000, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean = size > 1000
        }
    )

    private enum class Person { FIRST_SINGULAR, SECOND_SINGULAR, THIRD_SINGULAR, FIRST_PLURAL, SECOND_PLURAL, THIRD_PLURAL }
    private enum class Tense { PRESENT_CONTINUOUS, PAST_CONTINUOUS, PAST, FUTURE, AORIST, IMPERATIVE, CAN, MUST }
    private enum class VerbCase { NONE, ACCUSATIVE, DATIVE, ABLATIVE } // Yalın, -i hali, -e hali, -den hali

    private data class VerbEntry(val root: String, val requiredCase: VerbCase = VerbCase.NONE)

    // 1. Tam Kalıplar (Kelime sınırı \b ile korunur)
    private val phraseDictionary = mapOf(
        "press any key to continue" to "devam etmek için bir tuşa basın",
        "press any button" to "herhangi bir tuşa basın",
        "game over" to "oyun bitti",
        "mission failed" to "görev başarısız",
        "mission completed" to "görev tamamlandı",
        "checkpoint reached" to "kontrol noktasına ulaşıldı",
        "new objective" to "yeni hedef",
        "objective updated" to "hedef güncellendi",
        "what the hell" to "ne haltlar dönüyor",
        "what the fuck" to "ne oluyor lan",
        "son of a bitch" to "aşağılık herif",
        "what is going on" to "neler oluyor",
        "are you okay" to "iyi misin",
        "are you alright" to "iyi misin",
        "are you sure" to "emin misin",
        "i do not know" to "bilmiyorum",
        "i have no idea" to "hiçbir fikrim yok",
        "watch out" to "dikkat et",
        "look out" to "dikkat et",
        "heads up" to "dikkat et",
        "follow me" to "beni takip et",
        "stay here" to "burada kal",
        "stay back" to "geride dur",
        "let us go" to "hadi gidelim",
        "here we go" to "işte başlıyoruz",
        "come on" to "hadi ama", "get over here" to "gel buraya", "come here" to "buraya gel",
        "how are you" to "nasılsın",
        "hold on" to "bekle biraz",
        "hang on" to "dayan",
        "shut up" to "kapa çeneni",
        "get down" to "yere yat",
        "take cover" to "siper al",
        "cover me" to "beni koru",
        "out of ammo" to "mermi bitti",
        "no ammo" to "mermi yok",
        "it is locked" to "kilitli",
        "find a way" to "bir yolunu bul",
        "behind you" to "arkanda",
        "over there" to "şurada",
        "over here" to "burada",
        "right now" to "hemen şimdi",
        "of course" to "elbette",
        "no way" to "imkansız",
        "thank you" to "teşekkür ederim",
        "thanks" to "teşekkürler",
        "i am sorry" to "özür dilerim",
        "my bad" to "benim hatam",
        "be careful" to "dikkatli ol",
        "hurry up" to "acele et",
        "leave me alone" to "beni yalnız bırak",
        "calm down" to "sakin ol",
        "get out of here" to "buradan defol",
        "do not shoot" to "ateş etme",
        "hands up" to "eller yukarı",
        "drop your weapon" to "silahını bırak",
        "you are dead" to "öldün",
        "we need to go" to "gitmemiz gerekiyor",
        "i need help" to "yardıma ihtiyacım var",
        "see you later" to "sonra görüşürüz",
        "good luck" to "iyi şanslar",
        "well done" to "aferin",
        "nice job" to "iyi iş",
        "not yet" to "henüz değil",
        "almost there" to "neredeyse vardık",
        "too late" to "çok geç",
        "never mind" to "boşver",
        "forget it" to "unut gitsin",
        "it does not matter" to "önemi yok",
        "take it easy" to "sakin ol"
    )

    // 2. Birleşik Fiiller (Kelime sınırlarıyla aranır)
    private val phrasalVerbs = mapOf(
        "pick up" to "pick_up", "give up" to "give_up", "wake up" to "wake_up",
        "get up" to "get_up", "stand up" to "stand_up", "sit down" to "sit_down",
        "calm down" to "calm_down", "slow down" to "slow_down", "shut down" to "shut_down",
        "turn on" to "turn_on", "turn off" to "turn_off", "turn back" to "turn_back",
        "come back" to "come_back", "go back" to "go_back", "fall back" to "fall_back",
        "look for" to "look_for", "wait for" to "wait_for", "look at" to "look_at",
        "listen to" to "listen_to", "talk to" to "talk_to", "find out" to "find_out",
        "figure out" to "figure_out", "run away" to "run_away", "get away" to "get_away",
        "blow up" to "blow_up", "put down" to "put_down"
    )

    // 3. İsim ve Sıfat Sözlüğü (Tekrarlı anahtarlar temizlendi)
    private val nounAdjDictionary = mapOf(
        "this" to "bu", "that" to "şu", "these" to "bunlar", "those" to "şunlar",
        "here" to "burada", "there" to "orada", "never" to "asla", "always" to "her zaman",
        "maybe" to "belki", "perhaps" to "belki", "again" to "tekrar", "still" to "hala",
        "just" to "sadece", "already" to "zaten", "soon" to "yakında", "today" to "bugün",
        "tonight" to "bu gece", "tomorrow" to "yarın", "yesterday" to "dün",
        "very" to "çok", "too" to "fazla", "more" to "daha fazla", "only" to "yalnızca",
        "enough" to "yeterli", "almost" to "neredeyse", "together" to "birlikte", "alone" to "yalnız",
        "away" to "uzağa", "back" to "geri", "down" to "aşağı", "up" to "yukarı",
        "inside" to "içeride", "outside" to "dışarıda", "around" to "etrafta", "now" to "şimdi",

        "door" to "kapı", "gate" to "geçit", "window" to "pencere", "wall" to "duvar",
        "floor" to "zemin", "stairs" to "merdiven", "elevator" to "asansör",
        "key" to "anahtar", "lock" to "kilit", "code" to "şifre", "password" to "parola",
        "room" to "oda", "house" to "ev", "building" to "bina", "base" to "üs",
        "town" to "kasaba", "city" to "şehir", "village" to "köy", "world" to "dünya",
        "way" to "yol", "road" to "yol", "street" to "sokak", "path" to "patika",
        "place" to "yer", "area" to "bölge", "zone" to "alan", "point" to "nokta",
        "time" to "zaman", "day" to "gün", "night" to "gece", "morning" to "sabah",
        "man" to "adam", "men" to "adamlar", "woman" to "kadın", "women" to "kadınlar",
        "child" to "çocuk", "kid" to "çocuk", "girl" to "kız", "boy" to "çocuk", "guy" to "herif",
        "dude" to "ahbap", "sir" to "efendim", "captain" to "kaptan",
        "people" to "insanlar", "person" to "kişi", "family" to "aile", "brother" to "kardeş",
        "father" to "baba", "mother" to "anne", "sister" to "kız kardeş", "son" to "oğul", "daughter" to "kız",
        "friend" to "arkadaş", "partner" to "ortak", "team" to "ekip",
        "enemy" to "düşman", "target" to "hedef", "monster" to "canavar", "creature" to "yaratık",
        "zombie" to "zombi", "demon" to "iblis", "ghost" to "hayalet", "boss" to "patron",
        "gun" to "silah", "weapon" to "silah", "rifle" to "tüfek", "pistol" to "tabanca",
        "shotgun" to "pompalı", "knife" to "bıçak", "sword" to "kılıç", "blade" to "bıçak",
        "bomb" to "bomba", "grenade" to "el bombası", "bullet" to "mermi", "ammo" to "cephane",
        "armor" to "zırh", "shield" to "kalkan", "helmet" to "kask",
        "health" to "can", "medicine" to "ilaç", "life" to "hayat", "death" to "ölüm", "dead" to "ölü",
        "body" to "ceset", "head" to "kafa", "hand" to "el", "eye" to "göz", "heart" to "kalp",
        "mind" to "zihin", "soul" to "ruh", "blood" to "kan", "pain" to "acı",
        "fire" to "ateş", "water" to "su", "ice" to "buz", "air" to "hava", "earth" to "toprak",
        "light" to "ışık", "dark" to "karanlık", "darkness" to "karanlık", "shadow" to "gölge",
        "sound" to "ses", "noise" to "gürültü", "voice" to "ses", "silence" to "sessizlik",
        "truth" to "gerçek", "lie" to "yalan", "secret" to "sır", "story" to "hikaye",
        "power" to "güç", "energy" to "enerji", "magic" to "büyü", "system" to "sistem",
        "machine" to "makine", "computer" to "bilgisayar", "phone" to "telefon", "radio" to "telsiz",
        "camera" to "kamera", "security" to "güvenlik", "alarm" to "alarm",
        "map" to "harita", "item" to "eşya", "box" to "kutu", "chest" to "sandık", "bag" to "çanta",
        "money" to "para", "gold" to "altın", "coin" to "altın", "reward" to "ödül",
        "letter" to "mektup", "note" to "not", "book" to "kitap", "file" to "dosya",
        "car" to "araba", "truck" to "kamyon", "ship" to "gemi", "boat" to "tekne", "train" to "tren",
        "police" to "polis", "cop" to "polis", "guard" to "muhafız", "soldier" to "asker",
        "doctor" to "doktor", "king" to "kral", "lord" to "efendi", "god" to "tanrı",
        "job" to "iş", "work" to "iş", "mission" to "görev", "quest" to "görev", "plan" to "plan",
        "problem" to "sorun", "trouble" to "bela", "danger" to "tehlike", "trap" to "tuzak",
        "war" to "savaş", "battle" to "muharebe", "peace" to "barış",
        "chance" to "şans", "choice" to "seçim", "mistake" to "hata", "fault" to "suç",
        "end" to "son", "beginning" to "başlangıç", "part" to "parça", "side" to "taraf",
        "name" to "isim", "word" to "kelime", "question" to "soru", "answer" to "cevap",

        "good" to "iyi", "great" to "harika", "fine" to "iyi", "bad" to "kötü", "terrible" to "berbat",
        "new" to "yeni", "old" to "eski", "young" to "genç", "big" to "büyük", "large" to "geniş",
        "small" to "küçük", "little" to "küçük", "long" to "uzun", "short" to "kısa",
        "high" to "yüksek", "low" to "düşük", "deep" to "derin", "heavy" to "ağır",
        "fast" to "hızlı", "quick" to "çabuk", "slow" to "yavaş", "early" to "erken", "late" to "geç",
        "safe" to "güvenli", "dangerous" to "tehlikeli", "ready" to "hazır", "sure" to "emin",
        "right" to "doğru", "wrong" to "yanlış", "true" to "gerçek", "real" to "gerçek",
        "last" to "son", "next" to "sonraki", "first" to "ilk", "other" to "diğer", "another" to "başka bir",
        "same" to "aynı", "different" to "farklı", "special" to "özel", "important" to "önemli",
        "strong" to "güçlü", "weak" to "zayıf", "hard" to "zor", "easy" to "kolay",
        "open" to "açık", "closed" to "kapalı", "locked" to "kilitli", "broken" to "bozuk",
        "full" to "dolu", "empty" to "boş", "clean" to "temiz", "dirty" to "kirli",
        "cold" to "soğuk", "hot" to "sıcak", "warm" to "ılık",
        "happy" to "mutlu", "sad" to "üzgün", "angry" to "kızgın", "afraid" to "korkmuş", "scared" to "korkmuş",
        "crazy" to "çılgın", "insane" to "deli", "stupid" to "aptal", "smart" to "zeki",
        "strange" to "garip", "weird" to "tuhaf", "quiet" to "sessiz", "alive" to "hayatta",
        "everything" to "her şey", "nothing" to "hiçbir şey", "something" to "bir şey", "anything" to "herhangi bir şey",
        "everyone" to "herkes", "everybody" to "herkes", "someone" to "birisi", "anyone" to "herhangi biri", "nobody" to "hiç kimse",
        "everywhere" to "her yer", "somewhere" to "bir yer", "nowhere" to "hiçbir yer",
        "all" to "hepsi", "many" to "birçok", "much" to "çok", "some" to "bazı", "few" to "birkaç",
        "yes" to "evet", "yeah" to "evet", "yep" to "evet", "no" to "hayır", "nope" to "hayır",
        "okay" to "tamam", "ok" to "tamam", "alright" to "pekala", "please" to "lütfen",
        "hello" to "merhaba", "hi" to "selam", "hey" to "hey", "goodbye" to "hoşça kal", "bye" to "güle güle"
    )

    private val questionWords = mapOf(
        "what" to "ne", "where" to "nerede", "when" to "ne zaman",
        "who" to "kim", "why" to "neden", "how" to "nasıl", "which" to "hangi"
    )

    // 4. Fiil Sözlüğü + İstedikleri Hal Ekleri (Valence: ACCUSATIVE = -i hali, DATIVE = -e hali)
    private val verbDictionary = mapOf(
        "go" to VerbEntry("git", VerbCase.DATIVE),
        "come" to VerbEntry("gel", VerbCase.DATIVE),
        "see" to VerbEntry("gör", VerbCase.ACCUSATIVE),
        "look" to VerbEntry("bak", VerbCase.DATIVE),
        "look_at" to VerbEntry("bak", VerbCase.DATIVE),
        "look_for" to VerbEntry("ara", VerbCase.ACCUSATIVE),
        "watch" to VerbEntry("izle", VerbCase.ACCUSATIVE),
        "find" to VerbEntry("bul", VerbCase.ACCUSATIVE),
        "find_out" to VerbEntry("öğren", VerbCase.ACCUSATIVE),
        "figure_out" to VerbEntry("çöz", VerbCase.ACCUSATIVE),
        "lose" to VerbEntry("kaybet", VerbCase.ACCUSATIVE),
        "take" to VerbEntry("al", VerbCase.ACCUSATIVE),
        "pick_up" to VerbEntry("al", VerbCase.ACCUSATIVE),
        "get" to VerbEntry("al", VerbCase.ACCUSATIVE),
        "give" to VerbEntry("ver", VerbCase.ACCUSATIVE),
        "give_up" to VerbEntry("pes et", VerbCase.NONE),
        "use" to VerbEntry("kullan", VerbCase.ACCUSATIVE),
        "make" to VerbEntry("yap", VerbCase.ACCUSATIVE),
        "do" to VerbEntry("yap", VerbCase.ACCUSATIVE),
        "know" to VerbEntry("bil", VerbCase.ACCUSATIVE),
        "think" to VerbEntry("düşün", VerbCase.ACCUSATIVE),
        "understand" to VerbEntry("anla", VerbCase.ACCUSATIVE),
        "want" to VerbEntry("iste", VerbCase.ACCUSATIVE),
        "need" to VerbEntry("ihtiyaç duy", VerbCase.DATIVE),
        "like" to VerbEntry("sev", VerbCase.ACCUSATIVE),
        "love" to VerbEntry("sev", VerbCase.ACCUSATIVE),
        "hate" to VerbEntry("nefret et", VerbCase.ABLATIVE),
        "help" to VerbEntry("yardım et", VerbCase.DATIVE),
        "save" to VerbEntry("kurtar", VerbCase.ACCUSATIVE),
        "protect" to VerbEntry("koru", VerbCase.ACCUSATIVE),
        "kill" to VerbEntry("öldür", VerbCase.ACCUSATIVE),
        "die" to VerbEntry("öl", VerbCase.NONE),
        "run" to VerbEntry("koş", VerbCase.NONE),
        "run_away" to VerbEntry("kaç", VerbCase.ABLATIVE),
        "get_away" to VerbEntry("uzaklaş", VerbCase.ABLATIVE),
        "escape" to VerbEntry("kaç", VerbCase.ABLATIVE),
        "walk" to VerbEntry("yürü", VerbCase.NONE),
        "move" to VerbEntry("hareket et", VerbCase.NONE),
        "stop" to VerbEntry("dur", VerbCase.NONE),
        "wait" to VerbEntry("bekle", VerbCase.ACCUSATIVE),
        "wait_for" to VerbEntry("bekle", VerbCase.ACCUSATIVE),
        "stay" to VerbEntry("kal", VerbCase.NONE),
        "leave" to VerbEntry("terk et", VerbCase.ACCUSATIVE),
        "open" to VerbEntry("aç", VerbCase.ACCUSATIVE),
        "close" to VerbEntry("kapat", VerbCase.ACCUSATIVE),
        "shut" to VerbEntry("kapat", VerbCase.ACCUSATIVE),
        "turn_on" to VerbEntry("aç", VerbCase.ACCUSATIVE),
        "turn_off" to VerbEntry("kapat", VerbCase.ACCUSATIVE),
        "shut_down" to VerbEntry("kapat", VerbCase.ACCUSATIVE),
        "lock" to VerbEntry("kilitle", VerbCase.ACCUSATIVE),
        "unlock" to VerbEntry("kilidini aç", VerbCase.ACCUSATIVE),
        "hear" to VerbEntry("duy", VerbCase.ACCUSATIVE),
        "listen" to VerbEntry("dinle", VerbCase.ACCUSATIVE),
        "listen_to" to VerbEntry("dinle", VerbCase.ACCUSATIVE),
        "talk" to VerbEntry("konuş", VerbCase.NONE),
        "talk_to" to VerbEntry("konuş", VerbCase.NONE),
        "speak" to VerbEntry("konuş", VerbCase.NONE),
        "say" to VerbEntry("söyle", VerbCase.ACCUSATIVE),
        "tell" to VerbEntry("anlat", VerbCase.DATIVE),
        "call" to VerbEntry("ara", VerbCase.ACCUSATIVE),
        "ask" to VerbEntry("sor", VerbCase.DATIVE),
        "answer" to VerbEntry("cevapla", VerbCase.ACCUSATIVE),
        "try" to VerbEntry("dene", VerbCase.ACCUSATIVE),
        "start" to VerbEntry("başla", VerbCase.DATIVE),
        "begin" to VerbEntry("başla", VerbCase.DATIVE),
        "finish" to VerbEntry("bitir", VerbCase.ACCUSATIVE),
        "win" to VerbEntry("kazan", VerbCase.ACCUSATIVE),
        "fight" to VerbEntry("savaş", VerbCase.NONE),
        "attack" to VerbEntry("saldır", VerbCase.DATIVE),
        "shoot" to VerbEntry("vur", VerbCase.ACCUSATIVE),
        "hit" to VerbEntry("vur", VerbCase.DATIVE),
        "destroy" to VerbEntry("yok et", VerbCase.ACCUSATIVE),
        "break" to VerbEntry("kır", VerbCase.ACCUSATIVE),
        "blow_up" to VerbEntry("patlat", VerbCase.ACCUSATIVE),
        "fix" to VerbEntry("tamir et", VerbCase.ACCUSATIVE),
        "hide" to VerbEntry("saklan", VerbCase.NONE),
        "search" to VerbEntry("ara", VerbCase.ACCUSATIVE),
        "follow" to VerbEntry("takip et", VerbCase.ACCUSATIVE),
        "catch" to VerbEntry("yakala", VerbCase.ACCUSATIVE),
        "hold" to VerbEntry("tut", VerbCase.ACCUSATIVE),
        "keep" to VerbEntry("tut", VerbCase.ACCUSATIVE),
        "drop" to VerbEntry("bırak", VerbCase.ACCUSATIVE),
        "put_down" to VerbEntry("yere bırak", VerbCase.ACCUSATIVE),
        "throw" to VerbEntry("fırlat", VerbCase.ACCUSATIVE),
        "pull" to VerbEntry("çek", VerbCase.ACCUSATIVE),
        "push" to VerbEntry("it", VerbCase.ACCUSATIVE),
        "bring" to VerbEntry("getir", VerbCase.ACCUSATIVE),
        "send" to VerbEntry("gönder", VerbCase.ACCUSATIVE),
        "buy" to VerbEntry("satın al", VerbCase.ACCUSATIVE),
        "sell" to VerbEntry("sat", VerbCase.ACCUSATIVE),
        "pay" to VerbEntry("öde", VerbCase.ACCUSATIVE),
        "steal" to VerbEntry("çal", VerbCase.ACCUSATIVE),
        "trust" to VerbEntry("güven", VerbCase.DATIVE),
        "believe" to VerbEntry("inan", VerbCase.DATIVE),
        "remember" to VerbEntry("hatırla", VerbCase.ACCUSATIVE),
        "forget" to VerbEntry("unut", VerbCase.ACCUSATIVE),
        "feel" to VerbEntry("hisset", VerbCase.ACCUSATIVE),
        "forgive" to VerbEntry("affet", VerbCase.ACCUSATIVE),
        "hurt" to VerbEntry("incit", VerbCase.ACCUSATIVE),
        "turn" to VerbEntry("dön", VerbCase.DATIVE),
        "turn_back" to VerbEntry("geri dön", VerbCase.NONE),
        "come_back" to VerbEntry("geri gel", VerbCase.NONE),
        "go_back" to VerbEntry("geri git", VerbCase.NONE),
        "fall_back" to VerbEntry("geri çekil", VerbCase.NONE),
        "return" to VerbEntry("geri dön", VerbCase.DATIVE),
        "enter" to VerbEntry("gir", VerbCase.DATIVE),
        "reach" to VerbEntry("ulaş", VerbCase.DATIVE),
        "fall" to VerbEntry("düş", VerbCase.NONE),
        "jump" to VerbEntry("zıpla", VerbCase.NONE),
        "eat" to VerbEntry("ye", VerbCase.ACCUSATIVE),
        "drink" to VerbEntry("iç", VerbCase.ACCUSATIVE),
        "sleep" to VerbEntry("uyu", VerbCase.NONE),
        "wake_up" to VerbEntry("uyan", VerbCase.NONE),
        "get_up" to VerbEntry("kalk", VerbCase.NONE),
        "stand_up" to VerbEntry("ayağa kalk", VerbCase.NONE),
        "sit_down" to VerbEntry("otur", VerbCase.NONE),
        "calm_down" to VerbEntry("sakinleş", VerbCase.NONE),
        "slow_down" to VerbEntry("yavaşla", VerbCase.NONE),
        "read" to VerbEntry("oku", VerbCase.ACCUSATIVE),
        "write" to VerbEntry("yaz", VerbCase.ACCUSATIVE),
        "check" to VerbEntry("kontrol et", VerbCase.ACCUSATIVE),
        "touch" to VerbEntry("dokun", VerbCase.DATIVE)
    )

    private val irregularPastToKey = mapOf(
        "went" to "go", "came" to "come", "saw" to "see", "found" to "find",
        "took" to "take", "gave" to "give", "made" to "make", "did" to "do",
        "knew" to "know", "thought" to "think", "said" to "say", "told" to "tell",
        "got" to "get", "left" to "leave", "heard" to "hear", "ran" to "run",
        "fell" to "fall", "lost" to "lose", "won" to "win", "shot" to "shoot",
        "forgot" to "forget", "understood" to "understand", "brought" to "bring",
        "felt" to "feel", "kept" to "keep", "held" to "hold", "caught" to "catch",
        "sent" to "send", "paid" to "pay", "bought" to "buy", "sold" to "sell",
        "stole" to "steal", "broke" to "break", "spoke" to "speak", "wrote" to "write",
        "ate" to "eat", "drank" to "drink", "slept" to "sleep", "forgave" to "forgive"
    )

    // Her cümlede yeniden derlenmesin diye önceden hazırlanan kalıp desenleri (uzun kalıplar önce)
    private val phrasalPatterns: List<Pair<Regex, String>> =
        phrasalVerbs.entries.sortedByDescending { it.key.length }.map { Regex("\\b${it.key}\\b") to it.value }
    private val phrasePatterns: List<Pair<Regex, String>> =
        phraseDictionary.entries.filter { it.key.contains(" ") }.sortedByDescending { it.key.length }
            .map { Regex("\\b${it.key}\\b") to "[${it.value.replace(" ", "=")}]" }

    private val speakerRegex = Regex("^([A-Z][A-Za-z]{1,14}(?: [A-Z][A-Za-z]{1,14})?:)\\s*(.+)$")
    private val timeAdverbs = setOf("now", "today", "tonight", "tomorrow", "yesterday", "soon", "already", "again", "always")
    private val adjectiveParticiples = setOf("locked", "closed", "broken") // "is locked" = kilitli (fiil değil)
    private val ditransitiveRoots = setOf("ver", "anlat", "gönder", "getir")
    private val adverbCaseExempt = setOf("burada", "orada", "şimdi", "buraya", "oraya")
    private val objectPronouns = listOf("me", "you", "him", "her", "it", "us", "them")

    /**
     * Ana Çeviri Fonksiyonu.
     * Eğer cümlede bilinmeyen İngilizce kelimeler varsa yarı Türkçe-İngilizce bozuk çıktı
     * üretmemek için `null` döner (Böylece doğrudan ML Kit / Gemini devreye girer).
     */
    fun translateOrNull(rawInput: String): String? {
        val cleaned = cleanOcrNoise(rawInput)
        if (cleaned.isEmpty()) return null

        translationCache[cleaned]?.let { return it }

        val (speakerPrefix, bodyText) = extractSpeaker(cleaned)
        val sentences = bodyText.split(Regex("(?<=[.!?])\\s+"))
        val translatedSentences = mutableListOf<String>()

        for (s in sentences) {
            val translated = translateSingleSentence(s) ?: return null // Bilinmeyen kelime varsa iptal et
            translatedSentences.add(translated)
        }

        val finalOutput = speakerPrefix + translatedSentences.joinToString(" ")
        translationCache[cleaned] = finalOutput
        return finalOutput
    }

    private fun cleanOcrNoise(text: String): String {
        return text
            .replace(Regex("[♪♫#*~_|<>\\[\\]]"), "")
            .replace(Regex("\\b1\\b"), "I")
            .replace(Regex("\\bl'm\\b"), "I'm")
            .replace(Regex("\\bl\\b"), "I")
            .replace(Regex("\\.{2,}"), ".")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    /**
     * Sadece harfle başlayan konuşmacı isimlerini ("Leon: ") ayırır; "10:30" gibi saatleri eler.
     */
    private fun extractSpeaker(text: String): Pair<String, String> {
        val match = speakerRegex.find(text)
        return if (match != null) {
            Pair(match.groupValues[1] + " ", match.groupValues[2])
        } else {
            Pair("", text)
        }
    }

    private fun translateSingleSentence(sentence: String): String? {
        val isQuestionText = sentence.trim().endsWith("?")
        val endPunctuation = sentence.lastOrNull()?.takeIf { it in ".!?" } ?: ""

        // Orijinal metindeki özel isimleri (Büyük harfle başlayanları) tespit etmek için sakla
        val rawWords = sentence.replace(Regex("[^A-Za-z0-9\\s]"), " ").trim().split(Regex("\\s+"))
        val properNouns = rawWords.drop(1).filter { it.isNotEmpty() && it.first().isUpperCase() }.map { it.lowercase(Locale.ENGLISH) }.toSet()

        var normalized = expandContractions(sentence.lowercase(Locale.ENGLISH))
            .replace(Regex("[^a-z0-9\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        if (normalized.isEmpty()) return sentence

        // 1. Tam Kalıp Eşleşmesi
        phraseDictionary[normalized]?.let {
            return capitalizeTurkish(it) + endPunctuation
        }

        // 2. Kelime Sınırlı (\b) Phrasal Verb ve Kalıp Eşleşmesi ("forget upgrade" içinde "get up" bulmaz)
        for ((pattern, replacement) in phrasalPatterns) normalized = pattern.replace(normalized, replacement)
        for ((pattern, replacement) in phrasePatterns) normalized = pattern.replace(normalized, replacement)

        val tokens = normalized.split(" ").filter { it.isNotBlank() }.toMutableList()
        if (tokens.isEmpty()) return null
        val phraseUsed = tokens.any { it.startsWith("[") } // hazır kalıp ("nasılsın") zaten soru: ek "mı" eklenmez

        var person = Person.SECOND_SINGULAR // Özne yoksa varsayılan Emir Kipi (Sen)
        var hasExplicitSubject = false
        var tense = Tense.IMPERATIVE
        var isNegative = false
        var isQuestion = isQuestionText
        var questionWordTr: String? = null
        var questionWordEn: String? = null
        var auxSeen = false          // cümle yardımcı fiille başladı: sonraki "do" asıl fiildir
        var pastAux = false          // was/were: -ing ile birleşince geçmiş sürekli ("koşuyordu")
        var dativeGiven = false      // "give me the gun": önce dolaylı nesne (-e), sonra belirli nesne (-i)
        val adverbTokens = mutableListOf<String>()

        // Soru kelimesi başlangıçta mı? (Where, What, Who...)
        if (questionWords.containsKey(tokens.first())) {
            questionWordEn = tokens.removeAt(0)
            questionWordTr = questionWords[questionWordEn]
            isQuestion = true
        }

        // Yardımcı fiille başlayan soru kontrolü
        val negativeImperative = tokens.size > 1 && tokens[0] in listOf("do", "does") && tokens[1] == "not" && !isQuestionText
        if (negativeImperative) {
            tokens.removeAt(0) // "Do not go there." -> soru değil, olumsuz emir
        } else if (tokens.isNotEmpty() && tokens.first() in listOf("do", "does", "did", "am", "is", "are", "was", "were", "can", "will", "have", "has")) {
            isQuestion = true
            auxSeen = true
            when (tokens.removeAt(0)) {
                "did" -> tense = Tense.PAST
                "was", "were" -> { tense = Tense.PAST; pastAux = true }
                "will" -> tense = Tense.FUTURE
                "can" -> tense = Tense.CAN
                "am", "is", "are" -> tense = Tense.PRESENT_CONTINUOUS
                "do", "does" -> tense = Tense.AORIST
            }
        }

        var verbEntry: VerbEntry? = null
        val subjectTokens = mutableListOf<String>()
        val objectPhraseTokens = mutableListOf<String>()

        var i = 0
        while (i < tokens.size) {
            val token = tokens[i]

            if (token in listOf("the", "a", "an", "please")) {
                if (token == "please") subjectTokens.add("lütfen")
                i++
                continue
            }

            // Zaman ve Olumsuzluk Yardımcı Fiilleri
            when (token) {
                "not", "never" -> {
                    isNegative = true
                    if (token == "never") subjectTokens.add("asla")
                    i++; continue
                }
                "will" -> { tense = Tense.FUTURE; i++; continue }
                "can" -> { tense = Tense.CAN; i++; continue }
                "must", "should" -> { tense = Tense.MUST; i++; continue }
                "am", "is", "are" -> { tense = Tense.PRESENT_CONTINUOUS; i++; continue }
                "was", "were" -> { tense = Tense.PAST; pastAux = true; i++; continue }
                "had" -> { tense = Tense.PAST; i++; continue }
                // "did/do/does" yalnızca olumsuzlukta yardımcı fiildir; yoksa asıl fiildir ("I do my job", "did you do that")
                "did", "do", "does" -> if (!auxSeen && i + 1 < tokens.size && tokens[i + 1] == "not") {
                    tense = if (token == "did") Tense.PAST else Tense.AORIST
                    i++; continue
                }
                "let" -> {
                    if (i + 1 < tokens.size && tokens[i + 1] == "us") {
                        person = Person.FIRST_PLURAL
                        hasExplicitSubject = true
                        subjectTokens.add("hadi")
                        i += 2; continue
                    }
                }
            }

            // Fiil henüz bulunmadıysa: Fiil mi yoksa Özne mi kontrol et
            if (verbEntry == null) {
                val detected = if (token in adjectiveParticiples) null else extractVerbAndTense(token, tense)
                if (detected != null) {
                    verbEntry = detected.first
                    tense = if (pastAux && detected.second == Tense.PRESENT_CONTINUOUS) Tense.PAST_CONTINUOUS else detected.second
                    i++
                    continue
                }

                // Fiilden ÖNCE gelen zamirler ÖZNE'dir (person yalnızca burada güncellenir!)
                when (token) {
                    "i" -> { person = Person.FIRST_SINGULAR; hasExplicitSubject = true; i++; continue }
                    "you" -> { person = Person.SECOND_SINGULAR; hasExplicitSubject = true; i++; continue }
                    "he", "she", "it" -> { person = Person.THIRD_SINGULAR; hasExplicitSubject = true; i++; continue }
                    "we" -> { person = Person.FIRST_PLURAL; hasExplicitSubject = true; i++; continue }
                    "they" -> { person = Person.THIRD_PLURAL; hasExplicitSubject = true; i++; continue }
                }
            }

            // İyelik Tamlaması Kontrolü (Örn: "my brother", "your weapon")
            if (token in listOf("my", "your", "his", "her", "our", "their") && i + 1 < tokens.size) {
                val nextNoun = resolveNounOrNull(tokens[i + 1], properNouns) ?: return null
                val possessedNoun = applyPossessiveSuffix(nextNoun, token)
                if (verbEntry == null) {
                    person = Person.THIRD_SINGULAR
                    hasExplicitSubject = true
                    subjectTokens.add(possessedNoun)
                } else {
                    // Fiilden sonra geldiyse fiilin istediği hal ekini (-i / -e) iyelik üzerine ekle ("kardeşimi", "silahına")
                    val posCase = if (dativeGiven && verbEntry.requiredCase == VerbCase.DATIVE) VerbCase.ACCUSATIVE else verbEntry.requiredCase
                    val casedPossessed = applyCaseSuffix(possessedNoun, posCase, isPossessed = true)
                    objectPhraseTokens.add(casedPossessed)
                }
                i += 2
                continue
            }

            // Edat Evirme (in the room -> odada, with you -> seninle)
            if (token in listOf("in", "on", "under", "for", "with", "without", "from", "to", "about", "behind")) {
                val nextIdx = if (i + 1 < tokens.size && tokens[i + 1] in listOf("the", "a", "an")) i + 2 else i + 1
                if (nextIdx < tokens.size) {
                    val targetRaw = tokens[nextIdx]
                    val combined = resolvePrepositionPhrase(token, targetRaw, properNouns) ?: return null
                    objectPhraseTokens.add(combined)
                    i = nextIdx + 1
                    continue
                }
            }

            // Fiilden SONRA gelen zamirler NESNE'dir (Örn: "I love you" -> "you" = "seni", person DEĞİŞMEZ!)
            if (verbEntry != null && token in objectPronouns) {
                val indirect = verbEntry.root in ditransitiveRoots && !dativeGiven && i + 1 < tokens.size
                val objCase = if (indirect) VerbCase.DATIVE else verbEntry.requiredCase
                if (indirect) dativeGiven = true
                if (i + 1 < tokens.size && tokens[i + 1] == "all" && (token == "them" || token == "us")) {
                    objectPhraseTokens.add(allPronoun(token, objCase)) // "kill them all" -> "hepsini öldür"
                    i += 2
                    continue
                }
                objectPhraseTokens.add(resolveObjectPronoun(token, objCase))
                i++
                continue
            }

            // Normal İsim / Sıfat Çevirisi
            var resolved = resolveNounOrNull(token, properNouns) ?: return null
            if (token in timeAdverbs) {
                adverbTokens.add(resolved) // zaman zarfı cümle başına: "şimdi gitmemiz gerekiyor"
            } else if (verbEntry == null) {
                if (!hasExplicitSubject) { // "you are ready": sıfat, daha önce bulunan özneyi bozmaz
                    hasExplicitSubject = true
                    person = Person.THIRD_SINGULAR
                }
                subjectTokens.add(resolved)
            } else {
                if (token in listOf("here", "there") && verbEntry.requiredCase == VerbCase.DATIVE) {
                    resolved = if (token == "here") "buraya" else "oraya" // "go there" -> "oraya git"
                }
                // Nesne konumundaki isme fiilin istediği hal ekini uygula ("open the door" -> "kapıyı aç")
                val isLastObjectWord = (i == tokens.size - 1)
                val objCase = if (dativeGiven && verbEntry.requiredCase == VerbCase.DATIVE) VerbCase.ACCUSATIVE else verbEntry.requiredCase
                val finalObj = if (isLastObjectWord) applyCaseSuffix(resolved, objCase, isPossessed = false) else resolved
                objectPhraseTokens.add(finalObj)
            }
            i++
        }

        // 5. Türkçe Cümle Dizilimi (Özne + Nesne/Tümleç + Soru Kelimesi + Yüklem)
        val finalSentenceTokens = mutableListOf<String>()
        finalSentenceTokens.addAll(adverbTokens)
        finalSentenceTokens.addAll(subjectTokens)
        finalSentenceTokens.addAll(objectPhraseTokens)

        if (questionWordTr != null) {
            // "Where are you going?" -> "Nereye gidiyorsun?" (yönelme isteyen fiille)
            val whereToGo = questionWordEn == "where" && verbEntry?.requiredCase == VerbCase.DATIVE
            finalSentenceTokens.add(if (whereToGo) "nereye" else questionWordTr)
        }

        if (verbEntry != null) {
            if (tense == Tense.IMPERATIVE && hasExplicitSubject) {
                tense = Tense.PRESENT_CONTINUOUS
            }
            // Eğer cümlede "where/what/who" gibi soru kelimesi varsa ayrıca "mı/mi" eki eklenmez!
            val needsQuestionParticle = isQuestion && (questionWordTr == null)
            val conjugatedVerb = conjugateTurkishVerb(verbEntry.root, tense, person, isNegative, needsQuestionParticle)
            finalSentenceTokens.add(conjugatedVerb)
        } else {
            // İsim Cümlesi ("Are you ready?" -> "Hazır mısın?", "Where is my brother?" -> "Kardeşim nerede?")
            if (isNegative) {
                finalSentenceTokens.add(if (isQuestion && questionWordTr == null) "değil mi" else "değil" + copulaSuffix("değil", person))
            } else if (isQuestion && questionWordTr == null && !phraseUsed && finalSentenceTokens.isNotEmpty()) {
                val lastWord = finalSentenceTokens.removeLast()
                finalSentenceTokens.add(appendNominalQuestion(lastWord, person))
            } else if (!isQuestion && questionWordTr == null && hasExplicitSubject && subjectTokens.isNotEmpty() &&
                tense == Tense.PRESENT_CONTINUOUS && person in listOf(Person.FIRST_SINGULAR, Person.SECOND_SINGULAR, Person.FIRST_PLURAL)
            ) {
                // "I am ready" -> "Hazırım", "You are ready" -> "Hazırsın"
                val lastWord = finalSentenceTokens.removeLast()
                finalSentenceTokens.add(lastWord + copulaSuffix(lastWord, person))
            }
        }

        val output = finalSentenceTokens.joinToString(" ").replace(Regex("\\s+"), " ").trim()
        if (output.isEmpty()) return null
        return capitalizeTurkish(output) + endPunctuation
    }

    /**
     * Nesne zamirlerini fiilin istediği hal ekine göre çekimler
     */
    private fun resolveObjectPronoun(pronoun: String, verbCase: VerbCase): String {
        return when (verbCase) {
            VerbCase.DATIVE -> when (pronoun) {
                "me" -> "bana"; "you" -> "sana"; "him", "her", "it" -> "ona"
                "us" -> "bize"; "them" -> "onlara"; else -> "ona"
            }
            VerbCase.ABLATIVE -> when (pronoun) {
                "me" -> "benden"; "you" -> "senden"; "him", "her", "it" -> "ondan"
                "us" -> "bizden"; "them" -> "onlardan"; else -> "ondan"
            }
            else -> when (pronoun) { // ACCUSATIVE (-i hali)
                "me" -> "beni"; "you" -> "seni"; "him", "her", "it" -> "onu"
                "us" -> "bizi"; "them" -> "onları"; else -> "onu"
            }
        }
    }

    /**
     * İyelik Eki Uygulayıcı ("my brother" -> "kardeşim", "your door" -> "kapın")
     */
    private fun applyPossessiveSuffix(turkishNoun: String, possessor: String): String {
        val softened = softenNounForVowel(turkishNoun)
        val lastVowel = softened.lastOrNull { it in "aeıioöuü" } ?: 'e'
        val v = fourWayVowel(lastVowel)
        val endsWithVowel = softened.last() in "aeıioöuü"

        return when (possessor) {
            "my" -> if (endsWithVowel) "${softened}m" else "$softened${v}m"
            "your" -> if (endsWithVowel) "${softened}n" else "$softened${v}n"
            "his", "her" -> if (endsWithVowel) "${softened}s$v" else "$softened$v"
            "our" -> if (endsWithVowel) "${softened}m${v}z" else "$softened${v}m${v}z"
            "their" -> "$turkishNoun${if (lastVowel in "aıou") "ları" else "leri"}"
            else -> turkishNoun
        }
    }

    /**
     * İsme Hal Eki (-i, -e, -den) Uygulayıcı ("kardeşim" -> "kardeşimi", "kapı" -> "kapıyı")
     */
    private fun applyCaseSuffix(word: String, verbCase: VerbCase, isPossessed: Boolean): String {
        if (verbCase == VerbCase.NONE || word in adverbCaseExempt) return word
        if (word == "bu" || word == "şu") { // bu+i -> bunu, bu+e -> buna, bu+den -> bundan
            return word + when (verbCase) {
                VerbCase.ACCUSATIVE -> "nu"
                VerbCase.DATIVE -> "na"
                else -> "ndan"
            }
        }
        val softened = if (isPossessed) word else softenNounForVowel(word)
        val lastVowel = softened.lastOrNull { it in "aeıioöuü" } ?: 'e'
        val isBack = lastVowel in "aıou"
        val endsWithVowel = softened.last() in "aeıioöuü"
        val buffer = if (endsWithVowel) "y" else ""

        return when (verbCase) {
            VerbCase.ACCUSATIVE -> "$softened$buffer${fourWayVowel(lastVowel)}"
            VerbCase.DATIVE -> "$softened$buffer${if (isBack) "a" else "e"}"
            VerbCase.ABLATIVE -> {
                val dOrT = if (word.last() in "fstkçşhp") "t" else "d"
                "$word$dOrT${if (isBack) "an" else "en"}"
            }
            else -> word
        }
    }

    private fun softenNounForVowel(noun: String): String {
        if (noun.length < 3) return noun
        return when (noun.last()) {
            'p' -> noun.dropLast(1) + 'b'
            'ç' -> noun.dropLast(1) + 'c'
            'k' -> noun.dropLast(1) + 'ğ'
            else -> noun
        }
    }

    private fun resolvePrepositionPhrase(prep: String, targetRaw: String, properNouns: Set<String>): String? {
        if (targetRaw in listOf("me", "you", "him", "her", "us", "them")) {
            return when (prep) {
                "with" -> when (targetRaw) { "me" -> "benimle"; "you" -> "seninle"; "us" -> "bizimle"; else -> "onunla" }
                "for" -> when (targetRaw) { "me" -> "benim için"; "you" -> "senin için"; "us" -> "bizim için"; else -> "onun için" }
                "to" -> resolveObjectPronoun(targetRaw, VerbCase.DATIVE)
                "from" -> resolveObjectPronoun(targetRaw, VerbCase.ABLATIVE)
                else -> null
            }
        }
        val trWord = resolveNounOrNull(targetRaw, properNouns) ?: return null
        if (trWord == "bu" || trWord == "şu") {
            val gen = trWord + "nun" // bunun / şunun
            return when (prep) {
                "for" -> "$gen için"
                "about" -> "$gen hakkında"
                "with" -> "${trWord}nunla"
                "from" -> applyCaseSuffix(trWord, VerbCase.ABLATIVE, false)
                "to" -> applyCaseSuffix(trWord, VerbCase.DATIVE, false)
                "in", "on" -> "${trWord}nda"
                else -> null
            }
        }
        val lastVowel = trWord.lastOrNull { it in "aeıioöuü" } ?: 'e'
        val isBack = lastVowel in "aıou"
        val dOrT = if (trWord.last() in "fstkçşhp") 't' else 'd'
        val aOrE = if (isBack) 'a' else 'e'

        return when (prep) {
            "in", "on" -> "$trWord$dOrT$aOrE"
            "from" -> applyCaseSuffix(trWord, VerbCase.ABLATIVE, false)
            "to" -> applyCaseSuffix(trWord, VerbCase.DATIVE, false)
            "with" -> "$trWord ile"
            "without" -> "$trWord olmadan"
            "for" -> "$trWord için"
            "under" -> "$trWord altında"
            "behind" -> "$trWord arkasında"
            "about" -> "$trWord hakkında"
            else -> trWord
        }
    }

    /**
     * Bilinmeyen kelime varsa `null` döndürerek TV'de yarı İngilizce cümle çıkmasını engeller.
     */
    private fun resolveNounOrNull(token: String, properNouns: Set<String>): String? {
        if (token.startsWith("[") && token.endsWith("]")) {
            return token.removeSurrounding("[", "]").replace("=", " ")
        }
        nounAdjDictionary[token]?.let { return it }
        questionWords[token]?.let { return it }

        // Çoğul kontrolü
        if (token.endsWith("ies") && token.length > 4) {
            val singular = token.removeSuffix("ies") + "y"
            nounAdjDictionary[singular]?.let { root ->
                return "$root${if (root.lastOrNull { it in "aıou" } != null) "lar" else "ler"}"
            }
        }
        if (token.endsWith("s") && token.length > 3) {
            val singular = token.removeSuffix("s")
            nounAdjDictionary[singular]?.let { root ->
                return "$root${if (root.lastOrNull { it in "aıou" } != null) "lar" else "ler"}"
            }
        }

        // Özel isimse (Leon, Ada, Johnny) veya sayıysa koru, değilse NULL döndür!
        if (properNouns.contains(token) || token.all { it.isDigit() }) {
            return capitalizeTurkish(token)
        }
        return null
    }

    private fun extractVerbAndTense(token: String, currentTense: Tense): Pair<VerbEntry, Tense>? {
        irregularPastToKey[token]?.let { key ->
            verbDictionary[key]?.let { return Pair(it, Tense.PAST) }
        }
        verbDictionary[token]?.let { return Pair(it, currentTense) }

        if (token.endsWith("ing") && token.length > 4) {
            val base = token.removeSuffix("ing")
            val candidates = listOf(base, base + "e", if (base.length > 2 && base.last() == base[base.length - 2]) base.dropLast(1) else "")
            for (c in candidates) verbDictionary[c]?.let { return Pair(it, Tense.PRESENT_CONTINUOUS) }
        }
        if (token.endsWith("ed") && token.length > 3) {
            val base = token.removeSuffix("ed")
            val candidates = listOf(base, token.removeSuffix("d"), if (base.endsWith("i")) base.removeSuffix("i") + "y" else "")
            for (c in candidates) verbDictionary[c]?.let { return Pair(it, Tense.PAST) }
        }
        if (token.endsWith("s") && token.length > 3) {
            val candidates = listOf(token.removeSuffix("s"), token.removeSuffix("es"))
            for (c in candidates) verbDictionary[c]?.let { return Pair(it, Tense.PRESENT_CONTINUOUS) }
        }
        return null
    }

    /**
     * Türkçe Fiil Çekimleyici (kaybet -> kaybediyor, can't go -> gidemem düzeltmeleriyle)
     */
    private fun conjugateTurkishVerb(
        rawRoot: String,
        tense: Tense,
        person: Person,
        isNeg: Boolean,
        isQuestion: Boolean
    ): String {
        val lastVowel = rawRoot.lastOrNull { it in "aeıioöuü" } ?: 'e'
        val isBack = lastVowel in "aıou"
        val v4 = fourWayVowel(lastVowel)

        // 1. Emir Kipi
        if (tense == Tense.IMPERATIVE && !isQuestion) {
            if (person == Person.FIRST_PLURAL) {
                val softened = softenVerbRoot(rawRoot)
                return if (isNeg) "$rawRoot${if (isBack) "mayalım" else "meyelim"}" else "$softened${if (isBack) "alım" else "elim"}"
            }
            return if (isNeg) "$rawRoot${if (isBack) "ma" else "me"}" else rawRoot
        }

        // 2. Şimdiki / Geniş Zaman (-iyor)
        if (tense == Tense.PRESENT_CONTINUOUS || tense == Tense.AORIST) {
            val stem = if (isNeg) {
                "${rawRoot}m"
            } else {
                if (rawRoot.last() in "ae") rawRoot.dropLast(1) else softenVerbRoot(rawRoot)
            }
            val iyorVowel = if (isNeg) v4 else fourWayVowel(stem.lastOrNull { it in "aeıioöuü" } ?: lastVowel)
            val coreVerb = if (stem.last() !in "aeıioöuü") "$stem${iyorVowel}yor" else "${stem}yor"

            val pSuffix = when (person) {
                Person.FIRST_SINGULAR -> "um"
                Person.SECOND_SINGULAR -> "sun"
                Person.THIRD_SINGULAR -> ""
                Person.FIRST_PLURAL -> "uz"
                Person.SECOND_PLURAL -> "sunuz"
                Person.THIRD_PLURAL -> "lar"
            }
            return if (isQuestion) {
                val q = when (person) {
                    Person.FIRST_SINGULAR -> "muyum"
                    Person.SECOND_SINGULAR -> "musun"
                    Person.FIRST_PLURAL -> "muyuz"
                    else -> "mu"
                }
                "$coreVerb $q"
            } else "$coreVerb$pSuffix"
        }

        // 2b. Geçmiş sürekli (-iyordu): "she was running" -> "koşuyordu"
        if (tense == Tense.PAST_CONTINUOUS) {
            val stem = if (isNeg) "${rawRoot}m" else if (rawRoot.last() in "ae") rawRoot.dropLast(1) else softenVerbRoot(rawRoot)
            val iyorVowel = if (isNeg) v4 else fourWayVowel(stem.lastOrNull { it in "aeıioöuü" } ?: lastVowel)
            val core = if (stem.last() !in "aeıioöuü") "$stem${iyorVowel}yor" else "${stem}yor"
            val pSuffix = when (person) {
                Person.FIRST_SINGULAR -> "dum"; Person.SECOND_SINGULAR -> "dun"; Person.FIRST_PLURAL -> "duk"
                Person.THIRD_PLURAL -> "lardı"; else -> "du"
            }
            return if (isQuestion) "$core mu" + when (person) {
                Person.FIRST_SINGULAR -> "ydum"; Person.SECOND_SINGULAR -> "ydun"; Person.FIRST_PLURAL -> "yduk"; else -> "ydu"
            } else "$core$pSuffix"
        }

        // 3. Geçmiş Zaman (-dı / -di / -tı / -ti)
        if (tense == Tense.PAST) {
            val stem = if (isNeg) "$rawRoot${if (isBack) "ma" else "me"}" else rawRoot
            val sVowel = if (isNeg) (if (isBack) 'ı' else 'i') else v4
            val dOrT = if (stem.last() in "fstkçşhp") 't' else 'd'
            val pSuffix = when (person) {
                Person.FIRST_SINGULAR -> "m"; Person.SECOND_SINGULAR -> "n"
                Person.FIRST_PLURAL -> "k"; Person.THIRD_PLURAL -> if (isBack) "lar" else "ler"
                else -> ""
            }
            val conj = "$stem$dOrT$sVowel$pSuffix"
            return if (isQuestion) "$conj m$sVowel" else conj
        }

        // 4. Gelecek Zaman (-acak / -ecek)
        if (tense == Tense.FUTURE) {
            val stem = if (isNeg) "$rawRoot${if (isBack) "ma" else "me"}" else softenVerbRoot(rawRoot)
            val bufY = if (stem.last() in "aeıioöuü") "y" else ""
            val acak = if (isBack) "acak" else "ecek"
            val core = when (person) {
                Person.FIRST_SINGULAR -> "$stem$bufY${acak.dropLast(1)}${if (isBack) "ğım" else "ğim"}"
                Person.SECOND_SINGULAR -> "$stem$bufY$acak${if (isBack) "sın" else "sin"}"
                Person.FIRST_PLURAL -> "$stem$bufY${acak.dropLast(1)}${if (isBack) "ğız" else "ğiz"}"
                else -> "$stem$bufY$acak"
            }
            return if (isQuestion) "$stem$bufY$acak m${if (isBack) "ı" else "i"}" else core
        }

        // 5. Yeterlilik (-abilir / -ama / -eme) -> "gidemem", "yapamam" düzeltildi!
        if (tense == Tense.CAN) {
            val softened = softenVerbRoot(rawRoot)
            val bufY = if (softened.last() in "aeıioöuü") "y" else ""
            val aOrE = if (isBack) "a" else "e"
            val iOrI = if (isBack) "ı" else "i"

            return if (isNeg) {
                val negBase = "$softened$bufY${aOrE}m$aOrE" // gidem + e -> gideme, yapam + a -> yapama
                when (person) {
                    Person.FIRST_SINGULAR -> "${negBase}m"            // gidemem / yapamam
                    Person.SECOND_SINGULAR -> "${negBase}zs${iOrI}n"  // gidemezsin / yapamazsın
                    Person.FIRST_PLURAL -> "${negBase}y${iOrI}z"      // gidemeyiz / yapamayız
                    else -> "${negBase}z"                             // gidemez / yapamaz
                }
            } else {
                val posBase = "$softened$bufY${aOrE}bilir" // gidebilir / yapabilir (bilir her zaman ince 'i' ile biter)
                if (isQuestion) {
                    val q = when (person) {
                        Person.FIRST_SINGULAR -> "miyim"
                        Person.SECOND_SINGULAR -> "misin"
                        Person.FIRST_PLURAL -> "miyiz"
                        else -> "mi"
                    }
                    "$posBase$q"
                } else {
                    when (person) {
                        Person.FIRST_SINGULAR -> "${posBase}im"
                        Person.SECOND_SINGULAR -> "${posBase}sin"
                        Person.FIRST_PLURAL -> "${posBase}iz"
                        else -> posBase
                    }
                }
            }
        }

        // 6. Gereklilik (-malı / -meli)
        if (tense == Tense.MUST) {
            val neg = if (isNeg) (if (isBack) "ma" else "me") else ""
            val mali = if (isBack) "malı" else "meli"
            val pSuffix = when (person) {
                Person.FIRST_SINGULAR -> if (isBack) "yım" else "yim"
                Person.SECOND_SINGULAR -> if (isBack) "sın" else "sin"
                Person.FIRST_PLURAL -> if (isBack) "yız" else "yiz"
                else -> ""
            }
            return "$rawRoot$neg$mali$pSuffix"
        }

        return rawRoot
    }

    /** "hepsi" + hal: "them all" -> hepsini / hepsine, "us all" -> hepimizi / hepimize */
    private fun allPronoun(pronoun: String, verbCase: VerbCase): String {
        val base = if (pronoun == "us") "hepimiz" else "hepsi"
        return when (verbCase) {
            VerbCase.DATIVE -> if (pronoun == "us") "hepimize" else "hepsine"
            VerbCase.ABLATIVE -> if (pronoun == "us") "hepimizden" else "hepsinden"
            else -> if (pronoun == "us") "${base}i" else "hepsini"
        }
    }

    /** Ad cümlesi şahıs eki: hazır+ım, hazır+sın, hazır+ız (ünlü uyumu ve kaynaştırma "y" ile) */
    private fun copulaSuffix(word: String, person: Person): String {
        if (person !in listOf(Person.FIRST_SINGULAR, Person.SECOND_SINGULAR, Person.FIRST_PLURAL)) return ""
        val v = fourWayVowel(word.lastOrNull { it in "aeıioöuü" } ?: 'e')
        val endsWithVowel = word.last() in "aeıioöuü"
        val y = if (endsWithVowel) "y" else ""
        return when (person) {
            Person.FIRST_SINGULAR -> "$y${v}m"
            Person.SECOND_SINGULAR -> "s${v}n"
            else -> "$y${v}z"
        }
    }

    /**
     * Fiil yumuşaması: git -> gid, et -> ed, kaybet -> kaybed, hisset -> hissed, affet -> affed
     */
    private fun softenVerbRoot(root: String): String {
        val softenableEtVerbs = listOf("git", "et", "kaybet", "hisset", "affet", "seyret", "terk et", "yardım et", "takip et", "nefret et", "yok et", "tamir et", "kontrol et", "hareket et")
        if (root in softenableEtVerbs || root.endsWith(" et")) {
            return root.dropLast(1) + "d"
        }
        return root
    }

    private fun fourWayVowel(v: Char): Char = when (v) {
        'a', 'ı' -> 'ı'; 'e', 'i' -> 'i'; 'o', 'u' -> 'u'; 'ö', 'ü' -> 'ü'; else -> 'i'
    }

    private fun expandContractions(text: String): String {
        return text.replace("’", "'")
            .replace("\\bi'm\\b".toRegex(), "i am").replace("\\bim\\b".toRegex(), "i am")
            .replace("\\byou're\\b".toRegex(), "you are").replace("\\bwe're\\b".toRegex(), "we are").replace("\\bthey're\\b".toRegex(), "they are")
            .replace("\\bhe's\\b".toRegex(), "he is").replace("\\bshe's\\b".toRegex(), "she is").replace("\\bit's\\b".toRegex(), "it is")
            .replace("\\bdon't\\b".toRegex(), "do not").replace("\\bdont\\b".toRegex(), "do not")
            .replace("\\bdoesn't\\b".toRegex(), "does not").replace("\\bdidn't\\b".toRegex(), "did not").replace("\\bdidnt\\b".toRegex(), "did not")
            .replace("\\bcan't\\b".toRegex(), "can not").replace("\\bcant\\b".toRegex(), "can not")
            .replace("\\bwon't\\b".toRegex(), "will not").replace("\\bisn't\\b".toRegex(), "is not").replace("\\baren't\\b".toRegex(), "are not")
            .replace("\\bi'll\\b".toRegex(), "i will").replace("\\byou'll\\b".toRegex(), "you will").replace("\\bwe'll\\b".toRegex(), "we will")
            .replace("\\blet's\\b".toRegex(), "let us").replace("\\blets\\b".toRegex(), "let us")
            .replace("\\bwhat's\\b".toRegex(), "what is").replace("\\bwhere's\\b".toRegex(), "where is").replace("\\bwho's\\b".toRegex(), "who is")
            .replace("\\bgonna\\b".toRegex(), "will").replace("\\bwanna\\b".toRegex(), "want").replace("\\bgotta\\b".toRegex(), "must")
    }

    private fun appendNominalQuestion(word: String, person: Person): String {
        val v = fourWayVowel(word.lastOrNull { it in "aeıioöuü" } ?: 'e')
        val suffix = when (person) {
            Person.FIRST_SINGULAR -> "m${v}y${v}m"
            Person.SECOND_SINGULAR -> "m${v}s${v}n"
            Person.FIRST_PLURAL -> "m${v}y${v}z"
            else -> "m$v"
        }
        return "$word $suffix"
    }

    private fun capitalizeTurkish(text: String): String {
        if (text.isEmpty()) return text
        val upperFirst = when (val first = text.first()) {
            'i' -> 'İ'; 'ı' -> 'I'; else -> first.uppercaseChar()
        }
        return upperFirst + text.substring(1)
    }
}
