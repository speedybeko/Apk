package com.berkay.oyunceviri.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class FastGameTranslatorTest {

    private val t = FastGameTranslator()

    private fun tr(s: String): String? = t.translateOrNull(s)

    private fun check(expected: String, english: String) = assertEquals(english, expected, tr(english))

    @Test
    fun fixedPhrases() {
        check("Bekle biraz!", "Hold on!")
        check("İyi misin?", "Are you okay?")
        check("Gel buraya!", "Get over here!")
        check("Hadi gidelim.", "Let's go.")
    }

    @Test
    fun objectPronounsDoNotChangeTheSubject() {
        check("Seni seviyorum.", "I love you.")
        check("Seni öldüreceğim.", "I will kill you.")
        check("Senden nefret ediyorum.", "I hate you.")
        check("Onu gördüm.", "I saw him.")
    }

    @Test
    fun caseSuffixesFollowTheVerb() {
        check("Kapıyı aç.", "Open the door.")
        check("Anahtarı al.", "Take the key.")
        check("Kapıya bak.", "Look at the door.")
        check("Odaya git.", "Go to the room.")
        check("Kardeşimi öldürdü.", "He killed my brother.")
        check("Anahtarlarımı kaybettim.", "I lost my keys.")
        check("Bunu al.", "Take this.")
        check("Bunun için ödeyeceksin.", "You will pay for this.")
    }

    @Test
    fun indirectObjectComesBeforeTheDirectOne() {
        check("Bana silahı ver.", "Give me the gun.")
        check("Hepsini öldür!", "Kill them all!")
    }

    @Test
    fun questionsKeepTurkishWordOrder() {
        check("Anahtar nerede?", "Where is the key?")
        check("Kardeşim nerede?", "Where is my brother?")
        check("Benden ne istiyorsun?", "What do you want from me?")
        check("Hazır mısın?", "Are you ready?")
        check("Bana güveniyor musun?", "Do you trust me?")
    }

    @Test
    fun nominalSentencesGetPersonSuffixes() {
        check("Hazır değilsin.", "You are not ready.")
        check("Korkmuş değilim.", "I am not afraid.")
        check("Kapı kilitli.", "The door is locked.")
        check("Adam burada.", "The man is here.")
    }

    @Test
    fun negativeImperativeIsNotAQuestion() {
        check("Ateş etme!", "Don't shoot!")
        check("Oraya gitme.", "Don't go there.")
        check("Hareket etme!", "Don't move!")
    }

    @Test
    fun tensesAndModals() {
        check("Koşuyordu.", "She was running.")
        check("Gidemem.", "I can not go.")
        check("Kaçamazsın.", "You can not escape.")
        check("Anahtarı bulmalıyız.", "We must find the key.")
        check("Pes ediyorum.", "I give up.")
        check("Şimdi gitmemiz gerekiyor.", "We need to go now.")
    }

    @Test
    fun speakerNameIsKept() {
        check("Leon: Dikkat et arkanda!", "Leon: Watch out, behind you!")
    }

    @Test
    fun unknownWordsReturnNullInsteadOfHalfEnglishText() {
        assertNull(tr("I think we should leave this place before they find us."))
        assertNull(tr("It's the end of the world."))
        assertNull(tr("I need your help."))
    }

    @Test
    fun timesAndEnglishSentencesWithColonAreNotSpeakers() {
        assertNull(tr("Meeting at 10:30"))
    }

    @Test
    fun ocrNoiseIsCleaned() {
        check("Anahtarı bulacağım.", "♪ I will find the key. ♪")
        assertNotNull(tr("1 will find the key."))
    }

    @Test
    fun wordBoundariesAreRespectedForPhrasalVerbs() {
        // "forget upgrade" içinde "get up" bulunmamalı
        assertNull(tr("forget upgrade"))
    }

    @Test
    fun emptyInputIsNull() {
        assertNull(tr(""))
        assertNull(tr("   "))
    }

    @Test
    fun cachedResultIsStable() {
        val a = tr("Open the door.")
        assertEquals(a, tr("Open the door."))
    }
}
